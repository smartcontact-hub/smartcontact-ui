# Smart Contact · Tema para PrimeNG

Versión 0.20261026.1444 · 2026-10-26 · origen: Design System de Smart Contact (`8e0db0d6`)

Tema oficial de Smart Contact para aplicaciones Angular con PrimeNG. Es el mismo tema que utilizan las
aplicaciones de Smart Contact, por lo que los componentes se muestran de forma idéntica en ambos entornos.

## Contenido

| Fichero | Descripción |
|---|---|
| `sc-preset.mjs` | Preset de PrimeNG (la identidad de Smart Contact sobre Aura, que viene de `@primeuix/themes`). Incluye las variables `extend` que genera el plugin de Figma (`--p-typography-*`, `--p-app-typography-*`, `--p-presence-*`, `--p-component-custommodal-*`). |
| `sc-preset.d.ts` | Declaración de tipos para TypeScript. |
| `smartcontact-tokens.css` | Tokens de diseño `--sc-*`, modo claro y oscuro. |
| `smartcontact-typography.css` | Estilos de texto `.sc-text-*`. |
| `manifiesto.json` | Versión, origen y resultado de las comprobaciones. |

## Requisitos

- Angular con PrimeNG 21 o superior.
- `@primeuix/themes` 3.x instalado en el proyecto (`npm install @primeuix/themes`). El preset importa de ahí Aura y
  `definePreset`: el paquete no los incluye, porque son de PrimeTek y se usan bajo la licencia PrimeUI del proyecto.
- Tamaño de fuente raíz de 16 px (`html { font-size: 100% }`).
- Fuente Inter disponible en la aplicación.

## Instalación

1. Instalar el paquete desde el fichero `.tgz`:

   ```sh
   npm install ./local-libs/archives/smartcontact-tema.tgz
   ```

2. Añadir los estilos globales en `angular.json` → `styles`, a continuación de los estilos propios:

   ```json
   "node_modules/smartcontact-tema/smartcontact-tokens.css",
   "node_modules/smartcontact-tema/smartcontact-typography.css"
   ```

3. Configurar PrimeNG con el preset. El resto de opciones existentes se mantiene:

   ```ts
   import scPreset from 'smartcontact-tema';

   providePrimeNG({
     theme: { preset: scPreset, options: { prefix: 'p', darkModeSelector: '.sc-dark' } },
   });
   ```

4. Modo oscuro: añadir la clase `sc-dark` al elemento `<html>`. Afecta a la vez a los tokens y al preset.

## Estilos de texto

Cada estilo de texto de Figma tiene una clase en `smartcontact-typography.css` con el mismo nombre. Un texto que en
Figma lleva el estilo `Body/body-regular` se escribe con `class="sc-text-body-regular"`. La clase aplica tamaño,
interlineado, peso y familia desde los tokens `--sc-*`, así que el componente no necesita declarar `font-size` ni
`line-height`.

| Estilo en Figma | Clase |
|---|---|
| `Display/display-regular` | `sc-text-display-regular` |
| `Display/display-semibold` | `sc-text-display-semibold` |
| `Heading/h1-regular` | `sc-text-h1-regular` |
| `Heading/h1-semibold` | `sc-text-h1-semibold` |
| `Heading/h2-regular` | `sc-text-h2-regular` |
| `Heading/h2-semibold` | `sc-text-h2-semibold` |
| `Heading/h3-regular` | `sc-text-h3-regular` |
| `Heading/h3-semibold` | `sc-text-h3-semibold` |
| `Title/title-semibold` | `sc-text-title-semibold` |
| `Subtitle/subtitle-semibold` | `sc-text-subtitle-semibold` |
| `Body/body-regular` | `sc-text-body-regular` |
| `Body/body-semibold` | `sc-text-body-semibold` |
| `Caption/caption-regular` | `sc-text-caption-regular` |
| `Caption/caption-semibold` | `sc-text-caption-semibold` |

## Verificación

Con la aplicación en ejecución, en la consola del navegador:

```js
const v = (n) => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
[v('--p-primary-color'), v('--p-typography-font-size-100')];
```

Resultado esperado: `#1b273d` y un valor no vacío. Sin estilos propios que los modifiquen, los botones y
campos de tamaño normal miden 32,5 px de alto (27 px el pequeño y 40 px el grande).

## Actualización

Cada versión se distribuye con el mismo nombre de fichero, `smartcontact-tema.tgz`. Para actualizar,
basta con sustituir el fichero y ejecutar el comando del paso 1; la configuración no cambia. La versión
instalada figura en la cabecera de este documento y en `node_modules/smartcontact-tema/manifiesto.json`.

## Cambios respecto a la versión anterior

- Ficheros modificados: sc-preset.mjs.
- Tokens de diseño modificados: 0.
- Estilos comunes del tema: sin cambios.
- Reglas CSS del tema: sin cambios.
- Componentes con estilos modificados: toast.

## Comprobaciones de esta versión

- Ningún token de diseño con valor pasa a 0: superada.
- Variables `extend` del plugin de Figma definidas: 68 de 68.

---

Equipo de Diseño de Producto · Smart Contact
