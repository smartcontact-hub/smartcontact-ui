import type { OrganizationChartDesignTokens } from '@primeuix/themes/types/organizationchart';

 export default {
    root: {
        gutter: "0.75rem",
        transitionDuration: "{transition.duration}"
    },
    node: {
        background: "{content.background}",
        hoverBackground: "{content.hover.background}",
        selectedBackground: "{highlight.background}",
        borderColor: "{content.border.color}",
        color: "{content.color}",
        selectedColor: "{highlight.color}",
        hoverColor: "{content.hover.color}",
        padding: "0.75rem 1rem",
        toggleablePadding: "0.75rem 1rem 1.25rem",
        borderRadius: "{content.border.radius}",
        focusRing: {
            style: "solid"
        }
    },
    nodeToggleButton: {
        background: "{content.background}",
        hoverBackground: "{content.hover.background}",
        borderColor: "{content.border.color}",
        color: "{text.muted.color}",
        hoverColor: "{text.color}",
        size: "1.5rem",
        borderRadius: "0.75rem",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "none"
        }
    },
    connector: {
        color: "{content.border.color}",
        borderRadius: "{content.border.radius}",
        height: "24px"
    }
} satisfies OrganizationChartDesignTokens;