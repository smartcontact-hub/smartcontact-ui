import type { InplaceDesignTokens } from '@primeuix/themes/types/inplace';

 export default {
    root: {
        padding: "{form.field.padding.y} {form.field.padding.x}",
        borderRadius: "{content.border.radius}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "none"
        },
        transitionDuration: "{transition.duration}"
    },
    display: {
        hoverBackground: "{content.hover.background}",
        hoverColor: "{content.hover.color}"
    }
} satisfies InplaceDesignTokens;