import type { SplitButtonDesignTokens } from '@primeuix/themes/types/splitbutton';

 export default {
    root: {
        borderRadius: "{form.field.border.radius}",
        roundedBorderRadius: "2rem",
        raisedShadow: "0 3px 1px -2px #00000033, 0 2px 2px 0 #00000024, 0 1px 5px 0 #0000001f"
    }
} satisfies SplitButtonDesignTokens;