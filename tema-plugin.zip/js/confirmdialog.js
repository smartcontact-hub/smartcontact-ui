export default {
    icon: {
        size: "1.5rem",
        color: "{overlay.modal.color}"
    },
    content: {
        gap: "1rem"
    }
}